<?php

final class AdminCommissionRepository
{
    public function stats(): array
    {
        $statement = admin_db()->query(
            "SELECT status, COUNT(*) AS total, COALESCE(SUM(amount), 0) AS amount
             FROM commission_earnings
             GROUP BY status"
        );

        $stats = [
            'pending_count' => 0,
            'pending_amount' => 0.0,
            'approved_count' => 0,
            'approved_amount' => 0.0,
            'paid_count' => 0,
            'paid_amount' => 0.0,
            'cancelled_count' => 0,
            'cancelled_amount' => 0.0,
        ];

        foreach ($statement->fetchAll() as $row) {
            $status = $row['status'];
            $stats[$status . '_count'] = (int) $row['total'];
            $stats[$status . '_amount'] = (float) $row['amount'];
        }

        $payoutStatement = admin_db()->query(
            "SELECT status, COUNT(*) AS total, COALESCE(SUM(amount), 0) AS amount
             FROM commission_payouts
             GROUP BY status"
        );

        $stats['pending_payout_count'] = 0;
        $stats['pending_payout_amount'] = 0.0;
        foreach ($payoutStatement->fetchAll() as $row) {
            if ($row['status'] === 'pending') {
                $stats['pending_payout_count'] = (int) $row['total'];
                $stats['pending_payout_amount'] = (float) $row['amount'];
            }
        }

        return $stats;
    }

    public function rules(): array
    {
        $statement = admin_db()->query(
            "SELECT id, role, event_type, amount, currency, is_active, created_at, updated_at
             FROM commission_rules
             WHERE is_active = 1
             ORDER BY role, event_type"
        );

        return $statement->fetchAll();
    }

    public function saveRule(string $role, string $eventType, float $amount): void
    {
        $statement = admin_db()->prepare(
            'INSERT INTO commission_rules (role, event_type, amount, currency, is_active)
             VALUES (:role, :event_type, :amount, "PKR", 1)
             ON DUPLICATE KEY UPDATE amount = VALUES(amount), currency = VALUES(currency), is_active = 1'
        );
        $statement->execute([
            ':role' => $role,
            ':event_type' => $eventType,
            ':amount' => number_format($amount, 2, '.', ''),
        ]);
    }

    public function generateEarnings(): array
    {
        $dealerStatement = admin_db()->prepare(
            "INSERT INTO commission_earnings (user_id, role, source_type, source_id, amount, currency, earned_at)
             SELECT s.dealer_id, 'dealer', 'sale', s.id, rule.amount, rule.currency, CONCAT(s.sale_date, ' 00:00:00')
             FROM sales s
             INNER JOIN (
               SELECT amount, currency
               FROM commission_rules
               WHERE role = 'dealer' AND event_type = 'sale' AND is_active = 1
               ORDER BY id DESC
               LIMIT 1
             ) rule
             WHERE s.deleted_at IS NULL AND rule.amount > 0
             ON DUPLICATE KEY UPDATE
               amount = IF(commission_earnings.status = 'pending', VALUES(amount), commission_earnings.amount),
               updated_at = NOW()"
        );
        $dealerStatement->execute();

        $installerStatement = admin_db()->prepare(
            "INSERT INTO commission_earnings (user_id, role, source_type, source_id, amount, currency, earned_at)
             SELECT i.installer_id, 'installer', 'installation', i.id, rule.amount, rule.currency, i.installed_at
             FROM installations i
             INNER JOIN (
               SELECT amount, currency
               FROM commission_rules
               WHERE role = 'installer' AND event_type = 'installation' AND is_active = 1
               ORDER BY id DESC
               LIMIT 1
             ) rule
             WHERE i.deleted_at IS NULL AND rule.amount > 0
             ON DUPLICATE KEY UPDATE
               amount = IF(commission_earnings.status = 'pending', VALUES(amount), commission_earnings.amount),
               updated_at = NOW()"
        );
        $installerStatement->execute();

        return [
            'dealer' => $dealerStatement->rowCount(),
            'installer' => $installerStatement->rowCount(),
        ];
    }

    public function paginateEarnings(array $filters, int $page, int $limit): array
    {
        [$whereSql, $params] = $this->earningWhere($filters);
        $totalStatement = admin_db()->prepare(
            "SELECT COUNT(*)
             FROM commission_earnings ce
             INNER JOIN users u ON u.id = ce.user_id
             LEFT JOIN sales s ON ce.source_type = 'sale' AND s.id = ce.source_id
             LEFT JOIN installations i ON ce.source_type = 'installation' AND i.id = ce.source_id
             {$whereSql}"
        );
        $totalStatement->execute($params);
        $total = (int) $totalStatement->fetchColumn();

        $offset = ($page - 1) * $limit;
        $statement = admin_db()->prepare(
            "SELECT ce.id,
                    ce.user_id,
                    ce.role,
                    ce.source_type,
                    ce.source_id,
                    ce.amount,
                    ce.currency,
                    ce.status,
                    ce.payout_id,
                    ce.earned_at,
                    ce.approved_at,
                    ce.paid_at,
                    u.full_name,
                    u.mobile,
                    COALESCE(s.invoice_number, i.serial_number) AS source_label
             FROM commission_earnings ce
             INNER JOIN users u ON u.id = ce.user_id
             LEFT JOIN sales s ON ce.source_type = 'sale' AND s.id = ce.source_id
             LEFT JOIN installations i ON ce.source_type = 'installation' AND i.id = ce.source_id
             {$whereSql}
             ORDER BY ce.earned_at DESC, ce.id DESC
             LIMIT {$limit} OFFSET {$offset}"
        );
        $statement->execute($params);

        return ['total' => $total, 'items' => $statement->fetchAll()];
    }

    public function approvePending(): int
    {
        $statement = admin_db()->prepare(
            "UPDATE commission_earnings
             SET status = 'approved', approved_at = NOW(), updated_at = NOW()
             WHERE status = 'pending'"
        );
        $statement->execute();

        return $statement->rowCount();
    }

    public function createPayoutsForApproved(int $adminId): int
    {
        $pdo = admin_db();
        $pdo->beginTransaction();

        try {
            $groups = $pdo->query(
                "SELECT user_id, role, COALESCE(SUM(amount), 0) AS amount
                 FROM commission_earnings
                 WHERE status = 'approved' AND payout_id IS NULL
                 GROUP BY user_id, role
                 HAVING amount > 0"
            )->fetchAll();

            $created = 0;
            $insert = $pdo->prepare(
                'INSERT INTO commission_payouts (user_id, role, amount, status, created_by_admin_id)
                 VALUES (:user_id, :role, :amount, "pending", :created_by_admin_id)'
            );
            $update = $pdo->prepare(
                "UPDATE commission_earnings
                 SET payout_id = :payout_id, updated_at = NOW()
                 WHERE user_id = :user_id AND role = :role AND status = 'approved' AND payout_id IS NULL"
            );

            foreach ($groups as $group) {
                $insert->execute([
                    ':user_id' => (int) $group['user_id'],
                    ':role' => $group['role'],
                    ':amount' => number_format((float) $group['amount'], 2, '.', ''),
                    ':created_by_admin_id' => $adminId,
                ]);
                $payoutId = (int) $pdo->lastInsertId();
                $update->execute([
                    ':payout_id' => $payoutId,
                    ':user_id' => (int) $group['user_id'],
                    ':role' => $group['role'],
                ]);
                $created++;
            }

            $pdo->commit();
            return $created;
        } catch (Throwable $exception) {
            $pdo->rollBack();
            throw $exception;
        }
    }

    public function recentPayouts(int $limit = 20): array
    {
        $limit = max(1, min($limit, 50));
        $statement = admin_db()->query(
            "SELECT cp.id,
                    cp.user_id,
                    cp.role,
                    cp.amount,
                    cp.status,
                    cp.payment_reference,
                    cp.notes,
                    cp.paid_at,
                    cp.created_at,
                    u.full_name,
                    u.mobile,
                    COUNT(ce.id) AS earning_count
             FROM commission_payouts cp
             INNER JOIN users u ON u.id = cp.user_id
             LEFT JOIN commission_earnings ce ON ce.payout_id = cp.id
             GROUP BY cp.id
             ORDER BY cp.created_at DESC, cp.id DESC
             LIMIT {$limit}"
        );

        return $statement->fetchAll();
    }

    public function setPayoutStatus(int $payoutId, string $status, string $reference, string $notes): bool
    {
        $pdo = admin_db();
        $pdo->beginTransaction();

        try {
            if ($status === 'paid') {
                $statement = $pdo->prepare(
                    "UPDATE commission_payouts
                     SET status = 'paid',
                         payment_reference = :payment_reference,
                         notes = :notes,
                         paid_at = NOW(),
                         updated_at = NOW()
                     WHERE id = :id AND status = 'pending'"
                );
                $statement->execute([
                    ':id' => $payoutId,
                    ':payment_reference' => $reference !== '' ? $reference : null,
                    ':notes' => $notes !== '' ? $notes : null,
                ]);

                $earnings = $pdo->prepare(
                    "UPDATE commission_earnings
                     SET status = 'paid', paid_at = NOW(), updated_at = NOW()
                     WHERE payout_id = :payout_id AND status = 'approved'"
                );
                $earnings->execute([':payout_id' => $payoutId]);
            } else {
                $statement = $pdo->prepare(
                    "UPDATE commission_payouts
                     SET status = 'cancelled',
                         notes = :notes,
                         updated_at = NOW()
                     WHERE id = :id AND status = 'pending'"
                );
                $statement->execute([
                    ':id' => $payoutId,
                    ':notes' => $notes !== '' ? $notes : null,
                ]);

                $earnings = $pdo->prepare(
                    "UPDATE commission_earnings
                     SET payout_id = NULL, updated_at = NOW()
                     WHERE payout_id = :payout_id AND status = 'approved'"
                );
                $earnings->execute([':payout_id' => $payoutId]);
            }

            $updated = $statement->rowCount() > 0;
            $pdo->commit();
            return $updated;
        } catch (Throwable $exception) {
            $pdo->rollBack();
            throw $exception;
        }
    }

    public function logActivity(int $adminId, string $action, string $description): void
    {
        $statement = admin_db()->prepare(
            'INSERT INTO activity_logs (user_type, user_id, action, module, description, ip_address, user_agent)
             VALUES ("admin", :user_id, :action, "commissions", :description, :ip_address, :user_agent)'
        );
        $statement->execute([
            ':user_id' => $adminId,
            ':action' => $action,
            ':description' => $description,
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
        ]);
    }

    private function earningWhere(array $filters): array
    {
        $where = [];
        $params = [];

        if (($filters['search'] ?? '') !== '') {
            $where[] = '(u.full_name LIKE :search OR u.mobile LIKE :search OR s.invoice_number LIKE :search OR i.serial_number LIKE :search OR CAST(ce.source_id AS CHAR) LIKE :search)';
            $params[':search'] = '%' . $filters['search'] . '%';
        }
        if (($filters['role'] ?? '') !== '') {
            $where[] = 'ce.role = :role';
            $params[':role'] = $filters['role'];
        }
        if (($filters['status'] ?? '') !== '') {
            $where[] = 'ce.status = :status';
            $params[':status'] = $filters['status'];
        }
        if (($filters['date_from'] ?? '') !== '') {
            $where[] = 'DATE(ce.earned_at) >= :date_from';
            $params[':date_from'] = $filters['date_from'];
        }
        if (($filters['date_to'] ?? '') !== '') {
            $where[] = 'DATE(ce.earned_at) <= :date_to';
            $params[':date_to'] = $filters['date_to'];
        }

        return [$where ? 'WHERE ' . implode(' AND ', $where) : '', $params];
    }
}
