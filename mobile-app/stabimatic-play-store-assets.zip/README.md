# STABIMATIC Play Store Assets

Generated from the existing STABIMATIC logo and app styling.

Files:
- `play-store-icon-512.png` - Google Play app icon, 512 x 512.
- `feature-graphic-1024x500.png` - Google Play feature graphic, 1024 x 500.
- `phone-screenshot-01-login.png` - Phone screenshot, 1080 x 1920.
- `phone-screenshot-02-sale-serial-lookup.png` - Phone screenshot, 1080 x 1920.
- `phone-screenshot-03-installation-match.png` - Phone screenshot, 1080 x 1920.
- `phone-screenshot-04-commission-wallet.png` - Phone screenshot, 1080 x 1920.

Regenerate:
```powershell
cd D:\stabimatic\mobile-app
python scripts\generate-play-store-assets.py
```
